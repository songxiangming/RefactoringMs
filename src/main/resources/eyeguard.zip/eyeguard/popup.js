// Eye Guard Popup Script

document.addEventListener('DOMContentLoaded', async () => {
  const currentDomainEl = document.getElementById('current-domain');
  const statusTextEl = document.getElementById('status-text');
  const statusDotEl = document.getElementById('status-dot');
  const toggleBtn = document.getElementById('toggle-btn');
  const toggleTextEl = document.getElementById('toggle-text');
  const colorPicker = document.getElementById('color-picker');
  const colorValueEl = document.getElementById('color-value');
  const optionsLink = document.getElementById('options-link');
  const restrictedMessage = document.getElementById('restricted-message');
  const mainContent = document.querySelector('.main');

  const DEFAULT_COLOR = '#E8F5E9';

  // Get current domain status
  async function updateStatus() {
    try {
      const response = await chrome.runtime.sendMessage({ action: 'getDomainStatus' });
      
      if (!response.domain) {
        showRestricted();
        return;
      }

      // Check if it's a restricted URL
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab.url && (tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://'))) {
        showRestricted();
        return;
      }

      currentDomainEl.textContent = response.domain;
      
      // Get default color from storage
      const storage = await chrome.storage.sync.get(['defaultColor']);
      const defaultColor = storage.defaultColor || DEFAULT_COLOR;

      if (response.isActive) {
        setActiveState(response.color || defaultColor);
      } else {
        setInactiveState(defaultColor);
      }
    } catch (error) {
      console.error('Error getting status:', error);
      showRestricted();
    }
  }

  function showRestricted() {
    currentDomainEl.textContent = '—';
    restrictedMessage.style.display = 'block';
    toggleBtn.disabled = true;
    colorPicker.disabled = true;
  }

  function setActiveState(color) {
    statusTextEl.textContent = 'Protection On';
    statusDotEl.classList.remove('inactive');
    statusDotEl.classList.add('active');
    toggleTextEl.textContent = 'Disable Protection';
    toggleBtn.classList.add('active');
    colorPicker.value = color;
    colorValueEl.textContent = color.toUpperCase();
    colorPicker.disabled = false;
  }

  function setInactiveState(defaultColor) {
    statusTextEl.textContent = 'Protection Off';
    statusDotEl.classList.remove('active');
    statusDotEl.classList.add('inactive');
    toggleTextEl.textContent = 'Enable Protection';
    toggleBtn.classList.remove('active');
    colorPicker.value = defaultColor;
    colorValueEl.textContent = defaultColor.toUpperCase();
    colorPicker.disabled = true;
  }

  // Toggle protection for current domain
  toggleBtn.addEventListener('click', async () => {
    toggleBtn.disabled = true;
    
    try {
      const response = await chrome.runtime.sendMessage({ action: 'toggleDomain' });
      
      if (response.success) {
        const storage = await chrome.storage.sync.get(['defaultColor']);
        const defaultColor = storage.defaultColor || DEFAULT_COLOR;
        
        if (response.isActive) {
          setActiveState(colorPicker.value || defaultColor);
        } else {
          setInactiveState(defaultColor);
        }
      }
    } catch (error) {
      console.error('Error toggling domain:', error);
    }
    
    toggleBtn.disabled = false;
  });

  // Update color for current domain
  colorPicker.addEventListener('input', (e) => {
    colorValueEl.textContent = e.target.value.toUpperCase();
  });

  colorPicker.addEventListener('change', async (e) => {
    const color = e.target.value;
    colorValueEl.textContent = color.toUpperCase();
    
    try {
      await chrome.runtime.sendMessage({ 
        action: 'updateDomainColor', 
        color 
      });
    } catch (error) {
      console.error('Error updating color:', error);
    }
  });

  // Open options page
  optionsLink.addEventListener('click', (e) => {
    e.preventDefault();
    chrome.runtime.openOptionsPage();
  });

  // Initialize
  updateStatus();
});
