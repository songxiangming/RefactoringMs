// Eye Guard Options Page Script

document.addEventListener('DOMContentLoaded', async () => {
  const defaultColorInput = document.getElementById('default-color');
  const defaultColorValue = document.getElementById('default-color-value');
  const saveColorBtn = document.getElementById('save-color-btn');
  const domainListEl = document.getElementById('domain-list');
  const emptyStateEl = document.getElementById('empty-state');
  const exportBtn = document.getElementById('export-btn');
  const importBtn = document.getElementById('import-btn');
  const importFileInput = document.getElementById('import-file');
  const presetBtns = document.querySelectorAll('.preset-btn');
  const toastEl = document.getElementById('toast');

  const DEFAULT_COLOR = '#E8F5E9';

  // Show toast notification
  function showToast(message, type = 'success') {
    toastEl.textContent = message;
    toastEl.className = `toast show ${type}`;
    setTimeout(() => {
      toastEl.classList.remove('show');
    }, 3000);
  }

  // Load settings
  async function loadSettings() {
    const result = await chrome.storage.sync.get(['domains', 'defaultColor']);
    
    const defaultColor = result.defaultColor || DEFAULT_COLOR;
    defaultColorInput.value = defaultColor;
    defaultColorValue.textContent = defaultColor.toUpperCase();
    
    renderDomainList(result.domains || {});
  }

  // Render domain list
  function renderDomainList(domains) {
    const domainKeys = Object.keys(domains);
    
    if (domainKeys.length === 0) {
      emptyStateEl.style.display = 'flex';
      return;
    }
    
    emptyStateEl.style.display = 'none';
    
    // Clear existing domain items (keep empty state)
    const existingItems = domainListEl.querySelectorAll('.domain-item');
    existingItems.forEach(item => item.remove());
    
    // Sort domains alphabetically
    domainKeys.sort().forEach(domain => {
      const domainData = domains[domain];
      const domainItem = createDomainItem(domain, domainData);
      domainListEl.appendChild(domainItem);
    });
  }

  // Create domain list item
  function createDomainItem(domain, data) {
    const item = document.createElement('div');
    item.className = 'domain-item';
    item.dataset.domain = domain;
    
    item.innerHTML = `
      <div class="domain-info">
        <span class="domain-color" style="background-color: ${data.color || DEFAULT_COLOR};"></span>
        <span class="domain-name">${domain}</span>
      </div>
      <div class="domain-actions">
        <input type="color" class="domain-color-picker" value="${data.color || DEFAULT_COLOR}" title="Change color">
        <button class="btn-icon remove-btn" title="Remove domain">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
          </svg>
        </button>
      </div>
    `;
    
    // Color picker change handler
    const colorPicker = item.querySelector('.domain-color-picker');
    const colorSwatch = item.querySelector('.domain-color');
    
    colorPicker.addEventListener('change', async (e) => {
      const newColor = e.target.value;
      colorSwatch.style.backgroundColor = newColor;
      
      const result = await chrome.storage.sync.get(['domains']);
      const domains = result.domains || {};
      
      if (domains[domain]) {
        domains[domain].color = newColor;
        await chrome.storage.sync.set({ domains });
        showToast(`Updated color for ${domain}`);
      }
    });
    
    // Remove button handler
    const removeBtn = item.querySelector('.remove-btn');
    removeBtn.addEventListener('click', async () => {
      const result = await chrome.storage.sync.get(['domains']);
      const domains = result.domains || {};
      
      if (domains[domain]) {
        delete domains[domain];
        await chrome.storage.sync.set({ domains });
        
        item.classList.add('removing');
        setTimeout(() => {
          item.remove();
          
          // Check if list is empty
          const remainingItems = domainListEl.querySelectorAll('.domain-item');
          if (remainingItems.length === 0) {
            emptyStateEl.style.display = 'flex';
          }
        }, 300);
        
        showToast(`Removed ${domain}`);
      }
    });
    
    return item;
  }

  // Update color value display
  defaultColorInput.addEventListener('input', (e) => {
    defaultColorValue.textContent = e.target.value.toUpperCase();
  });

  // Save default color
  saveColorBtn.addEventListener('click', async () => {
    const color = defaultColorInput.value;
    await chrome.storage.sync.set({ defaultColor: color });
    showToast('Default color saved!');
  });

  // Preset color buttons
  presetBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const color = btn.dataset.color;
      defaultColorInput.value = color;
      defaultColorValue.textContent = color.toUpperCase();
    });
  });

  // Export settings
  exportBtn.addEventListener('click', async () => {
    const result = await chrome.storage.sync.get(['domains', 'defaultColor']);
    
    const exportData = {
      version: '1.0.0',
      exportDate: new Date().toISOString(),
      defaultColor: result.defaultColor || DEFAULT_COLOR,
      domains: result.domains || {}
    };
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `eyeguard-settings-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    
    URL.revokeObjectURL(url);
    showToast('Settings exported!');
  });

  // Import settings
  importBtn.addEventListener('click', () => {
    importFileInput.click();
  });

  importFileInput.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      
      if (!data.domains || typeof data.domains !== 'object') {
        throw new Error('Invalid settings file');
      }
      
      await chrome.storage.sync.set({
        domains: data.domains,
        defaultColor: data.defaultColor || DEFAULT_COLOR
      });
      
      await loadSettings();
      showToast('Settings imported successfully!');
    } catch (error) {
      showToast('Error importing settings: ' + error.message, 'error');
    }
    
    // Reset file input
    importFileInput.value = '';
  });

  // Listen for storage changes
  chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'sync') {
      if (changes.domains) {
        renderDomainList(changes.domains.newValue || {});
      }
      if (changes.defaultColor) {
        defaultColorInput.value = changes.defaultColor.newValue;
        defaultColorValue.textContent = changes.defaultColor.newValue.toUpperCase();
      }
    }
  });

  // Initialize
  loadSettings();
});
