// Eye Guard Content Script
// Applies background color protection to whitelisted domains

(function() {
  'use strict';

  const DEFAULT_COLOR = '#E8F5E9';
  let styleElement = null;
  let isApplied = false;

  // #region agent log
  const DEBUG_ENDPOINT = 'http://127.0.0.1:7242/ingest/4a905525-830a-40e3-8919-065eb616fa67';
  function debugLog(location, message, data, hypothesisId) {
    fetch(DEBUG_ENDPOINT, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location,message,data,hypothesisId,timestamp:Date.now(),sessionId:'debug-session',runId:'run1'})}).catch(()=>{});
  }
  // #endregion

  // Get the current domain
  function getCurrentDomain() {
    return window.location.hostname;
  }

  // Preserve elements that have background-image (thumbnails, video posters, etc.)
  function preserveBackgroundImageElements() {
    const elements = document.querySelectorAll('*');
    let preservedCount = 0;
    
    elements.forEach(el => {
      const style = getComputedStyle(el);
      // If element has a background-image, make it transparent so the image shows
      if (style.backgroundImage && style.backgroundImage !== 'none') {
        el.style.setProperty('background-color', 'transparent', 'important');
        preservedCount++;
      }
      
      // Also preserve parents of media elements
      if (el.querySelector('video, img, canvas, iframe, picture')) {
        const hasDirectMedia = Array.from(el.children).some(child => 
          ['VIDEO', 'IMG', 'CANVAS', 'IFRAME', 'PICTURE'].includes(child.tagName)
        );
        if (hasDirectMedia) {
          el.style.setProperty('background-color', 'transparent', 'important');
          preservedCount++;
        }
      }
    });

    // #region agent log
    debugLog('content.js:preserveBackgroundImageElements', 'Preserved elements with bg-image', {preservedCount}, 'B,D');
    // #endregion

    // Set up observer for dynamically added elements
    setupMutationObserver();
  }

  // Watch for new elements being added (for dynamic content like YouTube)
  let mutationObserver = null;
  function setupMutationObserver() {
    if (mutationObserver) return;
    
    mutationObserver = new MutationObserver((mutations) => {
      mutations.forEach(mutation => {
        mutation.addedNodes.forEach(node => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            const style = getComputedStyle(node);
            if (style.backgroundImage && style.backgroundImage !== 'none') {
              node.style.setProperty('background-color', 'transparent', 'important');
            }
            // Check children too
            node.querySelectorAll?.('*').forEach(child => {
              const childStyle = getComputedStyle(child);
              if (childStyle.backgroundImage && childStyle.backgroundImage !== 'none') {
                child.style.setProperty('background-color', 'transparent', 'important');
              }
            });
          }
        });
      });
    });
    
    mutationObserver.observe(document.body, { childList: true, subtree: true });
  }

  // Create and inject the style element
  function applyBackgroundColor(color) {
    if (styleElement) {
      removeBackgroundColor();
    }

    // #region agent log
    const mediaElements = {
      videos: document.querySelectorAll('video').length,
      imgs: document.querySelectorAll('img').length,
      iframes: document.querySelectorAll('iframe').length,
      canvas: document.querySelectorAll('canvas').length,
      bgImageDivs: Array.from(document.querySelectorAll('div')).filter(d => getComputedStyle(d).backgroundImage !== 'none').length
    };
    debugLog('content.js:applyBackgroundColor', 'Applying color, media elements found', {color, mediaElements}, 'A,B');
    // #endregion

    styleElement = document.createElement('style');
    styleElement.id = 'eyeguard-style';
    styleElement.textContent = `
      /* Apply to html and body for base coverage */
      html, body {
        background-color: ${color} !important;
      }
      
      /* Apply to common content elements, excluding media containers */
      article, section, main, aside, header, footer, nav,
      div, span, p, h1, h2, h3, h4, h5, h6,
      ul, ol, li, dl, dt, dd,
      table, thead, tbody, tfoot, tr, td, th,
      form, fieldset, legend, label,
      blockquote, pre, code,
      a, strong, em, mark, small, del, ins, sub, sup {
        background-color: ${color} !important;
      }
      
      /* Preserve all media elements and their containers */
      img, video, audio, canvas, svg, iframe, embed, object,
      picture, source, track, figure, figcaption {
        background-color: transparent !important;
      }
      
      /* Preserve elements with background-image (thumbnails, etc.) */
      [style*="background-image"],
      [style*="background:"] {
        background-color: transparent !important;
      }
      
      /* Preserve common video player containers */
      [class*="player"], [class*="Player"],
      [class*="video"], [class*="Video"],
      [class*="thumbnail"], [class*="Thumbnail"],
      [class*="poster"], [class*="Poster"],
      [class*="media"], [class*="Media"],
      [class*="ytd-"], [class*="ytp-"],
      [class*="html5-"], [class*="vjs-"],
      [id*="player"], [id*="Player"],
      [id*="video"], [id*="Video"] {
        background-color: transparent !important;
      }
      
      /* Form elements */
      input, textarea, select, button {
        background-color: ${color} !important;
      }
    `;

    // #region agent log
    debugLog('content.js:applyBackgroundColor', 'CSS rule created (new targeted approach)', {cssLength: styleElement.textContent.length}, 'C');
    // #endregion
    
    document.head.appendChild(styleElement);
    isApplied = true;
    
    // Preserve elements with computed background-image (CSS selectors can't detect these)
    preserveBackgroundImageElements();

    // #region agent log
    // Check if media elements are affected after applying
    setTimeout(() => {
      const sampleVideo = document.querySelector('video');
      const sampleImg = document.querySelector('img');
      const videoBgData = sampleVideo ? {
        tagName: 'video',
        computedBg: getComputedStyle(sampleVideo).backgroundColor,
        parentBg: sampleVideo.parentElement ? getComputedStyle(sampleVideo.parentElement).backgroundColor : null,
        parentTag: sampleVideo.parentElement?.tagName
      } : null;
      const imgBgData = sampleImg ? {
        tagName: 'img',
        computedBg: getComputedStyle(sampleImg).backgroundColor,
        parentBg: sampleImg.parentElement ? getComputedStyle(sampleImg.parentElement).backgroundColor : null,
        parentTag: sampleImg.parentElement?.tagName
      } : null;
      debugLog('content.js:postApply', 'Post-apply media check', {videoBgData, imgBgData}, 'C,D');
      
      // Check for elements with background-image that got covered
      const bgImageElements = Array.from(document.querySelectorAll('*')).filter(el => {
        const style = getComputedStyle(el);
        return style.backgroundImage !== 'none' && style.backgroundColor !== 'rgba(0, 0, 0, 0)';
      }).slice(0, 5).map(el => ({
        tag: el.tagName,
        className: el.className?.substring?.(0, 50) || '',
        bgColor: getComputedStyle(el).backgroundColor,
        bgImage: getComputedStyle(el).backgroundImage.substring(0, 100)
      }));
      debugLog('content.js:postApply', 'Elements with bgImage AND bgColor (potential issue)', {bgImageElements}, 'B,D');
    }, 500);
    // #endregion
  }

  // Remove the injected style
  function removeBackgroundColor() {
    if (styleElement) {
      styleElement.remove();
      styleElement = null;
    }
    if (mutationObserver) {
      mutationObserver.disconnect();
      mutationObserver = null;
    }
    isApplied = false;
  }

  // Check if current domain is in the whitelist and apply color
  async function checkAndApply() {
    const domain = getCurrentDomain();
    
    try {
      const result = await chrome.storage.sync.get(['domains', 'defaultColor']);
      const domains = result.domains || {};
      const defaultColor = result.defaultColor || DEFAULT_COLOR;
      
      if (domains[domain] && domains[domain].enabled) {
        const color = domains[domain].color || defaultColor;
        applyBackgroundColor(color);
      }
    } catch (error) {
      console.error('Eye Guard: Error loading settings', error);
    }
  }

  // Listen for messages from background script or popup
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'applyColor') {
      applyBackgroundColor(message.color || DEFAULT_COLOR);
      sendResponse({ success: true, applied: true });
    } else if (message.action === 'removeColor') {
      removeBackgroundColor();
      sendResponse({ success: true, applied: false });
    } else if (message.action === 'getStatus') {
      sendResponse({ 
        applied: isApplied, 
        domain: getCurrentDomain() 
      });
    } else if (message.action === 'updateColor') {
      if (isApplied) {
        applyBackgroundColor(message.color);
      }
      sendResponse({ success: true });
    }
    return true; // Keep message channel open for async response
  });

  // Initialize on page load
  checkAndApply();
})();
