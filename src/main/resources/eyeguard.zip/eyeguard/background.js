// Eye Guard Background Service Worker
// Handles keyboard shortcuts and messaging

const DEFAULT_COLOR = '#E8F5E9';

// Initialize default settings on install
chrome.runtime.onInstalled.addListener(async () => {
  const result = await chrome.storage.sync.get(['domains', 'defaultColor']);
  
  if (!result.domains) {
    await chrome.storage.sync.set({ domains: {} });
  }
  
  if (!result.defaultColor) {
    await chrome.storage.sync.set({ defaultColor: DEFAULT_COLOR });
  }
});

// Get the domain from a URL
function getDomainFromUrl(url) {
  try {
    const urlObj = new URL(url);
    return urlObj.hostname;
  } catch {
    return null;
  }
}

// Add domain to whitelist
async function addDomain(tabId, url) {
  const domain = getDomainFromUrl(url);
  if (!domain) return;

  const result = await chrome.storage.sync.get(['domains', 'defaultColor']);
  const domains = result.domains || {};
  const defaultColor = result.defaultColor || DEFAULT_COLOR;

  domains[domain] = {
    color: defaultColor,
    enabled: true
  };

  await chrome.storage.sync.set({ domains });

  // Notify content script to apply color
  try {
    await chrome.tabs.sendMessage(tabId, {
      action: 'applyColor',
      color: defaultColor
    });
  } catch (error) {
    console.log('Eye Guard: Could not send message to tab', error);
  }

  // Update badge
  updateBadge(tabId, true);
  
  // Show notification
  console.log(`Eye Guard: Added ${domain} to protection list`);
}

// Remove domain from whitelist
async function removeDomain(tabId, url) {
  const domain = getDomainFromUrl(url);
  if (!domain) return;

  const result = await chrome.storage.sync.get(['domains']);
  const domains = result.domains || {};

  if (domains[domain]) {
    delete domains[domain];
    await chrome.storage.sync.set({ domains });
  }

  // Notify content script to remove color
  try {
    await chrome.tabs.sendMessage(tabId, {
      action: 'removeColor'
    });
  } catch (error) {
    console.log('Eye Guard: Could not send message to tab', error);
  }

  // Update badge
  updateBadge(tabId, false);
  
  console.log(`Eye Guard: Removed ${domain} from protection list`);
}

// Update extension badge to show status
function updateBadge(tabId, isActive) {
  if (isActive) {
    chrome.action.setBadgeText({ text: 'ON', tabId });
    chrome.action.setBadgeBackgroundColor({ color: '#4CAF50', tabId });
  } else {
    chrome.action.setBadgeText({ text: '', tabId });
  }
}

// Check domain status and update badge when tab changes
async function checkTabStatus(tabId, url) {
  const domain = getDomainFromUrl(url);
  if (!domain) return;

  const result = await chrome.storage.sync.get(['domains']);
  const domains = result.domains || {};

  const isActive = domains[domain] && domains[domain].enabled;
  updateBadge(tabId, isActive);
}

// Listen for keyboard commands
chrome.commands.onCommand.addListener(async (command) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  if (!tab || !tab.url) return;
  
  // Skip chrome:// and other restricted URLs
  if (tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://')) {
    console.log('Eye Guard: Cannot modify Chrome internal pages');
    return;
  }

  if (command === 'add-domain') {
    await addDomain(tab.id, tab.url);
  } else if (command === 'remove-domain') {
    await removeDomain(tab.id, tab.url);
  }
});

// Listen for tab updates to check status
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url) {
    checkTabStatus(tabId, tab.url);
  }
});

// Listen for tab activation to update badge
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  const tab = await chrome.tabs.get(activeInfo.tabId);
  if (tab.url) {
    checkTabStatus(activeInfo.tabId, tab.url);
  }
});

// Listen for messages from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'getDomainStatus') {
    (async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab || !tab.url) {
        sendResponse({ domain: null, isActive: false });
        return;
      }
      
      const domain = getDomainFromUrl(tab.url);
      const result = await chrome.storage.sync.get(['domains']);
      const domains = result.domains || {};
      
      const domainData = domains[domain];
      sendResponse({
        domain,
        isActive: domainData ? domainData.enabled : false,
        color: domainData ? domainData.color : null
      });
    })();
    return true;
  }
  
  if (message.action === 'toggleDomain') {
    (async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab || !tab.url) {
        sendResponse({ success: false });
        return;
      }
      
      const domain = getDomainFromUrl(tab.url);
      const result = await chrome.storage.sync.get(['domains']);
      const domains = result.domains || {};
      
      if (domains[domain] && domains[domain].enabled) {
        await removeDomain(tab.id, tab.url);
        sendResponse({ success: true, isActive: false });
      } else {
        await addDomain(tab.id, tab.url);
        sendResponse({ success: true, isActive: true });
      }
    })();
    return true;
  }
  
  if (message.action === 'updateDomainColor') {
    (async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab || !tab.url) {
        sendResponse({ success: false });
        return;
      }
      
      const domain = getDomainFromUrl(tab.url);
      const result = await chrome.storage.sync.get(['domains']);
      const domains = result.domains || {};
      
      if (domains[domain]) {
        domains[domain].color = message.color;
        await chrome.storage.sync.set({ domains });
        
        try {
          await chrome.tabs.sendMessage(tab.id, {
            action: 'updateColor',
            color: message.color
          });
        } catch (error) {
          console.log('Eye Guard: Could not update color', error);
        }
      }
      
      sendResponse({ success: true });
    })();
    return true;
  }
});
